"""
holdings.py — Exports the Holdings report.

Steps:
  1. Call Oracle stored proc FINAL_HOLDINGS_REPORT(:effdate, :out_cursor) -> REF CURSOR
  2. Open Holdings_Template.xls
  3. Set cell B3 = effdate (date format)
  4. Write data rows from DataStartRow onward
  5. Validate per-scheme Script Weight in Fund sums to 99.99–100.02
  6. Save as Holdings_{dd-MMM-yy}.xls in OutputDirectory

Uses xlrd + xlwt + xlutils to handle the legacy .xls format.
"""

from datetime import date, datetime
from pathlib import Path

import oracledb
import xlrd
import xlwt
from xlutils.copy import copy as xl_copy

from logger import Logger


EXIT_CODE_HOLDINGS = 29

# Column indexes in the query result (0-based)
COL_SCHEME_NAME = 2   # Column C
COL_SCRIPT_WEIGHT = 12  # Column M


def export_holdings_report(
    cfg: dict,
    conn: oracledb.Connection,
    effdate: date,
    script_dir: Path,
    log: Logger,
) -> int:
    """
    Returns 0 on success, EXIT_CODE_HOLDINGS on failure.
    """
    hr_cfg = cfg.get("HoldingsReport")
    if not hr_cfg:
        log.warn("HoldingsReport not configured in appsettings.json — skipping.")
        return 0

    # Resolve template path
    template_str = hr_cfg.get("TemplatePath", "")
    template_path = Path(template_str) if Path(template_str).is_absolute() else script_dir / template_str
    if not template_path.exists():
        log.error(f"Holdings template not found: {template_path}")
        return EXIT_CODE_HOLDINGS

    output_dir = Path(hr_cfg["OutputDirectory"])
    data_start_row = int(hr_cfg.get("DataStartRow", 6)) - 1  # convert to 0-based

    date_label = effdate.strftime("%d-%b-%y")         # e.g. 20-Feb-26
    output_filename = f"Holdings_{date_label}.xls"
    output_path = output_dir / output_filename

    try:
        output_dir.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        log.error(f"Cannot create output directory {output_dir}: {e}")
        return EXIT_CODE_HOLDINGS

    # ------------------------------------------------------------------
    # Step 1: Call Oracle procedure and fetch data
    # ------------------------------------------------------------------
    log.info("Calling FINAL_HOLDINGS_REPORT stored procedure...")
    try:
        cur = conn.cursor()
        out_cursor = conn.cursor()
        cur.callproc("FINAL_HOLDINGS_REPORT", [effdate, out_cursor])
        columns = [col[0] for col in out_cursor.description]
        rows = out_cursor.fetchall()
        out_cursor.close()
        cur.close()
    except oracledb.Error as e:
        log.error(f"Oracle error calling FINAL_HOLDINGS_REPORT: {e}")
        return EXIT_CODE_HOLDINGS
    except Exception as e:
        log.error(f"Unexpected error calling FINAL_HOLDINGS_REPORT: {e}")
        return EXIT_CODE_HOLDINGS

    log.info(f"  Query returned {len(rows)} rows, {len(columns)} columns.")
    if not rows:
        log.warn("  WARNING: FINAL_HOLDINGS_REPORT returned 0 rows — file will be empty.")

    # ------------------------------------------------------------------
    # Step 2: Open template and write data
    # ------------------------------------------------------------------
    log.info(f"Opening template: {template_path}")
    try:
        rb = xlrd.open_workbook(str(template_path), formatting_info=True)
        wb = xl_copy(rb)
        ws = wb.get_sheet(0)
    except Exception as e:
        log.error(f"Failed to open Holdings template: {e}")
        return EXIT_CODE_HOLDINGS

    # Date format style
    date_style = xlwt.XFStyle()
    date_style.num_format_str = "DD-MMM-YY"

    # Step 3: Set B3 = effdate  (row=2, col=1 in 0-based)
    effdate_serial = _date_to_excel_serial(effdate)
    ws.write(2, 1, effdate_serial, date_style)

    # Step 4: Write data rows
    scheme_weights: dict[str, float] = {}

    for r_idx, row_data in enumerate(rows):
        xl_row = data_start_row + r_idx
        for c_idx, val in enumerate(row_data):
            if val is None:
                ws.write(xl_row, c_idx, "")
            elif isinstance(val, (datetime, date)):
                d = val if isinstance(val, date) else val.date()
                ws.write(xl_row, c_idx, _date_to_excel_serial(d), date_style)
            elif isinstance(val, (int, float)):
                ws.write(xl_row, c_idx, float(val))
            else:
                ws.write(xl_row, c_idx, str(val))

        # Accumulate scheme weights for validation
        try:
            scheme = row_data[COL_SCHEME_NAME]
            weight = row_data[COL_SCRIPT_WEIGHT]
            if scheme is not None and weight is not None:
                scheme_str = str(scheme).strip()
                wt_val = float(weight)
                if scheme_str and not (wt_val != wt_val):  # skip NaN
                    scheme_weights[scheme_str] = scheme_weights.get(scheme_str, 0.0) + wt_val
        except Exception:
            pass  # don't abort export over a weight accumulation error

    # Step 5: Validate per-scheme weights
    if scheme_weights:
        failed = {s: w for s, w in scheme_weights.items() if not (99.99 <= w <= 100.02)}
        if failed:
            log.warn("Holdings validation — schemes NOT summing to ~100% (99.99–100.02):")
            for scheme, total in sorted(failed.items()):
                log.warn(f"  Scheme '{scheme}' total Script Weight = {total:.6f}")
            log.warn("File will still be saved.")
        else:
            log.info(f"Holdings weight validation: all {len(scheme_weights)} schemes sum to ~100%. OK.")

    # Step 6: Save output
    try:
        wb.save(str(output_path))
        log.info(f"Holdings report saved: {output_path}")
        return 0
    except Exception as e:
        log.error(f"Failed to save Holdings report: {e}")
        return EXIT_CODE_HOLDINGS


def _date_to_excel_serial(d: date) -> int:
    """Convert a Python date to Excel OA date serial (days since 1899-12-30)."""
    base = date(1899, 12, 30)
    return (d - base).days
